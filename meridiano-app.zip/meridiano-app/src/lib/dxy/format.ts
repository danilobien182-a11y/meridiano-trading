const MONTHS = [
  "ene",
  "feb",
  "mar",
  "abr",
  "may",
  "jun",
  "jul",
  "ago",
  "sep",
  "oct",
  "nov",
  "dic",
] as const;

export function formatNum(n: number, digits = 2): string {
  if (!Number.isFinite(n)) return "—";
  const neg = n < 0;
  const [whole, frac] = Math.abs(n).toFixed(digits).split(".");
  const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  const body = frac ? `${grouped},${frac}` : grouped;
  return neg ? `−${body}` : body;
}

export function formatInt(n: number): string {
  return formatNum(n, 0);
}

export function formatSigned(n: number, digits = 2): string {
  if (!Number.isFinite(n)) return "—";
  if (Number(Math.abs(n).toFixed(digits)) === 0) return formatNum(0, digits);
  return n > 0 ? `+${formatNum(n, digits)}` : formatNum(n, digits);
}

export function formatDay(iso: string): string {
  const [y, m, d] = iso.split("-");
  return `${Number(d)} ${MONTHS[Number(m) - 1] ?? m} ${y}`;
}

export function formatDayShort(iso: string): string {
  const [, m, d] = iso.split("-");
  return `${Number(d)} ${MONTHS[Number(m) - 1] ?? m}`;
}

export function addBusinessDays(iso: string, days: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  let left = days;
  while (left > 0) {
    dt.setUTCDate(dt.getUTCDate() + 1);
    const wd = dt.getUTCDay();
    if (wd !== 0 && wd !== 6) left -= 1;
  }
  return dt.toISOString().slice(0, 10);
}

export function sessionNote(lastDate: string, now: Date): string {
  const nyToday = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/New_York",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
  const nyWd = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    weekday: "short",
  }).format(now);
  if (nyToday === lastDate) return `Sesión de Nueva York · ${formatDay(lastDate)}`;
  if (nyWd === "Sat" || nyWd === "Sun") {
    return `Mercado cerrado · último cierre del ${formatDay(lastDate)}. El futuro reabre el domingo por la tarde, hora de Nueva York.`;
  }
  return `Último cierre disponible · ${formatDay(lastDate)}`;
}

export function fetchedLabel(now: Date): string {
  return new Intl.DateTimeFormat("es-ES", {
    timeZone: "Europe/Madrid",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(now);
}
