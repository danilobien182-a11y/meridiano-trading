import { bandFor, LEGS, type LegId } from "@/lib/dxy/ice";
import { formatDay, formatInt, formatNum, formatSigned, sessionNote } from "@/lib/dxy/format";
import type {
  Bias,
  Driver,
  HorizonId,
  HorizonView,
  LegView,
  Level,
  SeriesPoint,
  Snapshot,
  Tone,
  YieldView,
} from "@/lib/dxy/types";

export type RawBar = {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
};

/** Foreign currency per 1 USD, as published by the ECB via Frankfurter. */
export type FxRow = {
  eur: number;
  jpy: number;
  gbp: number;
  cad: number;
  sek: number;
  chf: number;
};

export type BuildInput = {
  bars: RawBar[];
  yields: Record<string, number>;
  fx: Record<string, FxRow>;
  now: Date;
  fetchedLabel: string;
  notices: string[];
};

const HORIZONS: { id: HorizonId; label: string; sessions: number }[] = [
  { id: 1, label: "1 sesión", sessions: 1 },
  { id: 5, label: "1 semana", sessions: 5 },
  { id: 20, label: "1 mes", sessions: 20 },
];

function ema(values: number[], period: number): (number | null)[] {
  const out: (number | null)[] = Array(values.length).fill(null);
  const k = 2 / (period + 1);
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i === period - 1) out[i] = sum / period;
    else if (i >= period) out[i] = values[i] * k + (out[i - 1] as number) * (1 - k);
  }
  return out;
}

function atr14(bars: RawBar[]): (number | null)[] {
  const n = bars.length;
  const out: (number | null)[] = Array(n).fill(null);
  const tr = Array(n).fill(0);
  for (let i = 1; i < n; i++) {
    const prev = bars[i - 1].close;
    tr[i] = Math.max(
      bars[i].high - bars[i].low,
      Math.abs(bars[i].high - prev),
      Math.abs(bars[i].low - prev),
    );
  }
  const p = 14;
  if (n <= p) return out;
  let seed = 0;
  for (let i = 1; i <= p; i++) seed += tr[i];
  out[p] = seed / p;
  for (let i = p + 1; i < n; i++) out[i] = ((out[i - 1] as number) * (p - 1) + tr[i]) / p;
  return out;
}

function alignFx(dates: string[], fx: Record<string, FxRow>): (FxRow | null)[] {
  const keys = Object.keys(fx).sort();
  let j = 0;
  let last: FxRow | null = null;
  const out: (FxRow | null)[] = [];
  for (const date of dates) {
    while (j < keys.length && keys[j] <= date) {
      last = fx[keys[j]] ?? last;
      j += 1;
    }
    out.push(last);
  }
  return out;
}

function pairPrice(row: FxRow, id: LegId): number {
  if (id === "eur") return 1 / row.eur;
  if (id === "gbp") return 1 / row.gbp;
  if (id === "jpy") return row.jpy;
  if (id === "cad") return row.cad;
  if (id === "sek") return row.sek;
  return row.chf;
}

function toneOf(n: number): Tone {
  if (n > 0) return "up";
  if (n < 0) return "down";
  return "flat";
}

function coverRate(
  closes: number[],
  atr: (number | null)[],
  sessions: number,
  k: number,
): { rate: number; samples: number } {
  let inside = 0;
  let samples = 0;
  for (let i = 40; i + sessions < closes.length; i++) {
    const a = atr[i];
    if (a == null) continue;
    const mom = closes[i] - closes[i - 20];
    const band = bandFor(closes[i], a, mom, sessions);
    const half = k === 0.45 ? (band.innerHigh - band.innerLow) / 2 : (band.outerHigh - band.outerLow) / 2;
    const fwd = closes[i + sessions] - closes[i];
    samples += 1;
    if (Math.abs(fwd - band.shift) <= half + 1e-9) inside += 1;
  }
  return { rate: samples ? inside / samples : 0, samples };
}

function directionHit(
  closes: number[],
  sessions: number,
): { rate: number; samples: number } {
  let hit = 0;
  let samples = 0;
  for (let i = 20; i + sessions < closes.length; i++) {
    const signal = closes[i] - closes[i - 20];
    const fwd = closes[i + sessions] - closes[i];
    if (signal === 0 || fwd === 0) continue;
    samples += 1;
    if (Math.sign(signal) === Math.sign(fwd)) hit += 1;
  }
  return { rate: samples ? hit / samples : 0, samples };
}

function yieldBeta(
  dates: string[],
  closes: number[],
  yields: Record<string, number>,
  spot: number,
): YieldView | null {
  const xs: number[] = [];
  const ys: number[] = [];
  for (let i = 1; i < closes.length; i++) {
    const y0 = yields[dates[i - 1]];
    const y1 = yields[dates[i]];
    if (y0 == null || y1 == null || closes[i - 1] === 0) continue;
    xs.push((y1 - y0) * 100);
    ys.push((closes[i] / closes[i - 1] - 1) * 100);
  }
  if (xs.length < 40) return null;
  const n = xs.length;
  let mx = 0;
  let my = 0;
  for (let i = 0; i < n; i++) {
    mx += xs[i];
    my += ys[i];
  }
  mx /= n;
  my /= n;
  let varx = 0;
  let vary = 0;
  let cov = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i] - mx;
    const dy = ys[i] - my;
    varx += dx * dx;
    vary += dy * dy;
    cov += dx * dy;
  }
  if (varx === 0 || vary === 0) return null;
  const betaPctPerBp = cov / varx;
  const corr = cov / Math.sqrt(varx * vary);
  const lastDate = [...dates].reverse().find((d) => yields[d] != null);
  if (!lastDate) return null;
  let chg10bp: number | null = null;
  const lastIdx = dates.lastIndexOf(lastDate);
  const prevIdx = lastIdx - 10;
  if (prevIdx >= 0 && yields[dates[prevIdx]] != null) {
    chg10bp = (yields[lastDate] - yields[dates[prevIdx]]) * 100;
  }
  return {
    last: yields[lastDate],
    date: lastDate,
    chg10bp,
    pointsPer10bp: (betaPctPerBp * 10 * spot) / 100,
    corr,
    samples: n,
  };
}

function buildReading(
  bias: Bias,
  intensity: Snapshot["intensity"],
  mom20Pct: number,
  mom5Pct: number,
  hitRate: number,
  samples: number,
): string {
  const pct = `${formatSigned(mom20Pct, 2)}%`;
  if (bias === "neutral") {
    return `En veinte sesiones el dólar no tiene una inercia clara (${pct}). El centro del rango se queda en el último cierre: aquí se anticipa el tamaño del movimiento, no la dirección.`;
  }
  const way = bias === "alcista" ? "al alza" : "a la baja";
  const lead =
    intensity === "clara"
      ? `La inercia de veinte sesiones es clara y apunta ${way} (${pct}).`
      : `Hay una inclinación leve ${way} (${pct} en veinte sesiones).`;
  const contra =
    Math.sign(mom5Pct) !== 0 && Math.sign(mom5Pct) !== Math.sign(mom20Pct)
      ? " Las últimas cinco sesiones van en sentido contrario, así que el centro apenas se separa del cierre."
      : " Aun así el centro apenas se separa del cierre: una ventaja pequeña no justifica un objetivo lejano.";
  return `${lead} Seguir esa inercia acertó el signo a una semana el ${Math.round(hitRate * 100)}% de las veces, en ${formatInt(samples)} ventanas de esta historia. El azar anda por el 50%.${contra}`;
}

export function buildSnapshot(input: BuildInput): Snapshot {
  const bars = input.bars;
  if (bars.length < 80) throw new Error("La serie del DXY es demasiado corta para estimar un rango.");
  const closes = bars.map((b) => b.close);
  const dates = bars.map((b) => b.date);
  const atr = atr14(bars);
  const ema21 = ema(closes, 21);
  const ema55 = ema(closes, 55);
  const last = bars.length - 1;
  const a = atr[last];
  const e21 = ema21[last];
  const e55 = ema55[last];
  if (a == null || e21 == null || e55 == null) {
    throw new Error("No hay suficiente historia para las medias del índice.");
  }

  const spot = closes[last];
  const prev = closes[last - 1];
  const mom20Points = spot - closes[last - 20];
  const mom5Points = spot - closes[last - 5];
  const mom20Pct = (mom20Points / closes[last - 20]) * 100;
  const mom5Pct = (mom5Points / closes[last - 5]) * 100;
  const ratio = mom20Points / closes[last - 20];
  const tilt = Math.tanh(ratio / 0.015);
  const intensity: Snapshot["intensity"] =
    Math.abs(tilt) < 0.25 ? "nula" : Math.abs(tilt) < 0.7 ? "leve" : "clara";
  const bias: Bias = intensity === "nula" ? "neutral" : tilt > 0 ? "alcista" : "bajista";

  const hit5 = directionHit(closes, 5);
  const year = bars.slice(-252);
  const high52 = Math.max(...year.map((b) => b.high));
  const low52 = Math.min(...year.map((b) => b.low));
  const month = bars.slice(-20);
  const high20 = Math.max(...month.map((b) => b.high));
  const low20 = Math.min(...month.map((b) => b.low));

  const levels: Level[] = [
    { id: "h52", label: "Máximo de 52 semanas", price: high52, distance: high52 - spot },
    { id: "h20", label: "Máximo de 20 sesiones", price: high20, distance: high20 - spot },
    { id: "e21", label: "Media de 21 sesiones", price: e21, distance: e21 - spot },
    { id: "e55", label: "Media de 55 sesiones", price: e55, distance: e55 - spot },
    { id: "l20", label: "Mínimo de 20 sesiones", price: low20, distance: low20 - spot },
    { id: "l52", label: "Mínimo de 52 semanas", price: low52, distance: low52 - spot },
  ].sort((p, q) => q.price - p.price);

  const aligned = alignFx(dates, input.fx);
  const fxNow = aligned[last];
  const fxThen = aligned[last - 5];
  let legs: LegView[] | null = null;
  let fxDate: string | null = null;
  let basketPoints5: number | null = null;
  if (fxNow && fxThen) {
    const fxDates = Object.keys(input.fx).sort();
    fxDate = [...fxDates].reverse().find((d) => d <= dates[last]) ?? null;
    legs = LEGS.map((leg) => {
      const price = pairPrice(fxNow, leg.id);
      const before = pairPrice(fxThen, leg.id);
      const points5 = spot * leg.weight * Math.log(price / before);
      return {
        id: leg.id,
        name: leg.name,
        pair: leg.pair,
        weightLabel: leg.weightLabel,
        weight: leg.weight,
        price,
        chg5Pct: (price / before - 1) * 100,
        points5,
      };
    });
    basketPoints5 = legs.reduce((s, leg) => s + leg.points5, 0);
  }

  const iceChange5 = spot - closes[last - 5];
  const yield10 = yieldBeta(dates, closes, input.yields, spot);

  const drivers: Driver[] = [
    {
      id: "mom20",
      label: "Inercia",
      value: `${formatSigned(mom20Pct, 2)}%`,
      hint: "variación en 20 sesiones",
      tone: toneOf(mom20Points),
    },
    {
      id: "mom5",
      label: "Última semana",
      value: `${formatSigned(mom5Pct, 2)}%`,
      hint: "variación en 5 sesiones",
      tone: toneOf(mom5Points),
    },
    {
      id: "ema",
      label: "Media de 21",
      value: `${formatSigned(spot - e21, 2)} pts`,
      hint: spot >= e21 ? "el cierre está por encima" : "el cierre está por debajo",
      tone: toneOf(spot - e21),
    },
  ];

  if (legs) {
    const sign = Math.sign(iceChange5);
    const withMove =
      sign === 0 ? 0 : legs.filter((leg) => Math.sign(leg.points5) === sign).length;
    drivers.push({
      id: "basket",
      label: "Cesta",
      value: sign === 0 ? "Cruzada" : `${withMove} de 6`,
      hint:
        sign === 0
          ? "el índice casi no se movió en 5 días"
          : "patas a favor del movimiento de 5 días",
      tone: "flat",
    });
  } else {
    drivers.push({
      id: "basket",
      label: "Cesta",
      value: "Sin dato",
      hint: "el fixing BCE no llegó",
      tone: "flat",
    });
  }

  if (yield10) {
    drivers.push({
      id: "yield",
      label: "T-Note 10 años",
      value: `${formatNum(yield10.last, 2)}%`,
      hint:
        yield10.chg10bp == null
          ? `cierre del ${formatDay(yield10.date)}`
          : `${formatSigned(yield10.chg10bp, 0)} pb en 10 sesiones`,
      tone: toneOf(yield10.chg10bp ?? 0),
    });
  } else {
    drivers.push({
      id: "yield",
      label: "T-Note 10 años",
      value: "Sin dato",
      hint: "no se pudo leer el bono",
      tone: "flat",
    });
  }

  const horizons: HorizonView[] = HORIZONS.map((h) => {
    const band = bandFor(spot, a, mom20Points, h.sessions);
    const inner = coverRate(closes, atr, h.sessions, 0.45);
    const outer = coverRate(closes, atr, h.sessions, 0.82);
    const hit = directionHit(closes, h.sessions);
    return {
      id: h.id,
      label: h.label,
      sessions: h.sessions,
      ...band,
      innerCover: inner.rate,
      outerCover: outer.rate,
      coverSamples: inner.samples,
      hitRate: hit.rate,
      hitSamples: hit.samples,
    };
  });

  const series: SeriesPoint[] = bars.map((bar, i) => ({
    date: bar.date,
    close: bar.close,
    ema21: ema21[i],
  }));

  const bar = bars[last];
  return {
    spot,
    prev,
    change: spot - prev,
    changePct: (spot / prev - 1) * 100,
    atr: a,
    mom20Points,
    lastDate: bar.date,
    sessionNote: sessionNote(bar.date, input.now),
    fetchedLabel: input.fetchedLabel,
    reading: buildReading(bias, intensity, mom20Pct, mom5Pct, hit5.rate, hit5.samples),
    bias,
    intensity,
    tilt,
    ema21: e21,
    ema55: e55,
    session: {
      date: bar.date,
      open: bar.open,
      high: bar.high,
      low: bar.low,
      close: bar.close,
    },
    series,
    drivers,
    legs,
    fxDate,
    iceChange5,
    basketPoints5,
    levels,
    horizons,
    yield10,
    notices: input.notices,
  };
}
