import { createServerFn } from "@tanstack/react-start";
import { buildSnapshot, type FxRow, type RawBar } from "@/lib/dxy/analyze";
import { fetchedLabel } from "@/lib/dxy/format";
import type { MarketResult, Snapshot } from "@/lib/dxy/types";

const DXY_URL =
  "https://query1.finance.yahoo.com/v8/finance/chart/DX-Y.NYB?interval=1d&range=5y";
const YIELD_URL =
  "https://query1.finance.yahoo.com/v8/finance/chart/%5ETNX?interval=1d&range=5y";
const FX_START = "2021-01-01";

type YahooResult = {
  meta?: {
    regularMarketPrice?: number;
    regularMarketTime?: number;
    regularMarketDayHigh?: number;
    regularMarketDayLow?: number;
  };
  timestamp?: number[];
  indicators?: {
    quote?: Array<{
      open?: Array<number | null>;
      high?: Array<number | null>;
      low?: Array<number | null>;
      close?: Array<number | null>;
    }>;
  };
};

let cache: { at: number; snapshot: Snapshot } | null = null;
const TTL_MS = 10 * 60 * 1000;

function nyDate(unixSec: number): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/New_York",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(unixSec * 1000));
}

async function fetchJson(url: string): Promise<unknown> {
  const res = await fetch(url, {
    headers: {
      Accept: "application/json",
      "User-Agent": "Mozilla/5.0",
    },
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function parseYahoo(payload: unknown): { bars: RawBar[]; meta: YahooResult["meta"] } {
  const chart = (payload as { chart?: { result?: YahooResult[]; error?: { description?: string } } })
    .chart;
  const result = chart?.result?.[0];
  if (!result?.timestamp || !result.indicators?.quote?.[0]) {
    throw new Error(chart?.error?.description || "Respuesta vacía");
  }
  const quote = result.indicators.quote[0];
  const bars: RawBar[] = [];
  for (let i = 0; i < result.timestamp.length; i++) {
    const close = quote.close?.[i];
    const high = quote.high?.[i];
    const low = quote.low?.[i];
    const open = quote.open?.[i];
    if (close == null || high == null || low == null || open == null) continue;
    bars.push({
      date: nyDate(result.timestamp[i]),
      open,
      high,
      low,
      close,
    });
  }
  return { bars, meta: result.meta };
}

function applySpot(bars: RawBar[], meta: YahooResult["meta"]): RawBar[] {
  if (!bars.length || !meta) return bars;
  const px = meta.regularMarketPrice;
  if (px == null || !Number.isFinite(px)) return bars;
  const sessionDate = meta.regularMarketTime ? nyDate(meta.regularMarketTime) : bars[bars.length - 1].date;
  const next = bars.map((bar) => ({ ...bar }));
  const last = next[next.length - 1];
  if (!last || Math.abs(px / last.close - 1) > 0.02) return next;
  if (sessionDate !== last.date) return next;
  last.close = px;
  const hi = meta.regularMarketDayHigh;
  const lo = meta.regularMarketDayLow;
  if (hi != null && Number.isFinite(hi)) last.high = Math.max(last.high, hi, px);
  if (lo != null && Number.isFinite(lo)) last.low = Math.min(last.low, lo, px);
  last.high = Math.max(last.high, px);
  last.low = Math.min(last.low, px);
  return next;
}

function parseYields(payload: unknown): Record<string, number> {
  const { bars } = parseYahoo(payload);
  const out: Record<string, number> = {};
  for (const bar of bars) out[bar.date] = bar.close;
  return out;
}

function parseFx(payload: unknown): Record<string, FxRow> {
  const rates = (payload as { rates?: Record<string, Record<string, number>> }).rates ?? {};
  const out: Record<string, FxRow> = {};
  for (const [date, row] of Object.entries(rates)) {
    const eur = row.EUR;
    const jpy = row.JPY;
    const gbp = row.GBP;
    const cad = row.CAD;
    const sek = row.SEK;
    const chf = row.CHF;
    if ([eur, jpy, gbp, cad, sek, chf].some((n) => n == null || !Number.isFinite(n) || n <= 0)) {
      continue;
    }
    out[date] = { eur, jpy, gbp, cad, sek, chf };
  }
  return out;
}

export const getMarket = createServerFn({ method: "GET" }).handler(async (): Promise<MarketResult> => {
  try {
    const now = Date.now();
    if (cache && now - cache.at < TTL_MS) {
      return { ok: true, snapshot: cache.snapshot };
    }
    const [dxyRes, yldRes, fxRes] = await Promise.allSettled([
      fetchJson(DXY_URL),
      fetchJson(YIELD_URL),
      fetchJson(
        `https://api.frankfurter.dev/v1/${FX_START}..?from=USD&to=EUR,JPY,GBP,CAD,SEK,CHF`,
      ),
    ]);
    if (dxyRes.status === "rejected") {
      return {
        ok: false,
        error: "No hay cotización del DXY en este momento. Prueba de nuevo en unos minutos.",
      };
    }
    const parsed = parseYahoo(dxyRes.value);
    const bars = applySpot(parsed.bars, parsed.meta);
    if (bars.length < 80) {
      return { ok: false, error: "La serie del índice llegó incompleta." };
    }
    const notices: string[] = [];
    let yields: Record<string, number> = {};
    if (yldRes.status === "fulfilled") {
      try {
        yields = parseYields(yldRes.value);
      } catch {
        notices.push("El bono a 10 años no se pudo leer. El rango del índice sí está actualizado.");
      }
    } else {
      notices.push("El bono a 10 años no se pudo leer. El rango del índice sí está actualizado.");
    }
    let fx: Record<string, FxRow> = {};
    if (fxRes.status === "fulfilled") {
      fx = parseFx(fxRes.value);
      if (Object.keys(fx).length < 30) {
        fx = {};
        notices.push("La cesta de divisas no llegó completa. El índice y su rango sí.");
      }
    } else {
      notices.push("La cesta de divisas no se pudo leer. El índice y su rango sí.");
    }
    const stamp = new Date();
    const snapshot = buildSnapshot({
      bars,
      yields,
      fx,
      now: stamp,
      fetchedLabel: fetchedLabel(stamp),
      notices,
    });
    cache = { at: now, snapshot };
    return { ok: true, snapshot };
  } catch {
    return {
      ok: false,
      error: "No se pudo preparar la anticipación del DXY. Prueba de nuevo en unos minutos.",
    };
  }
});
