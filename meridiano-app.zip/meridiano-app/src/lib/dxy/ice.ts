/** Official ICE Dollar Index geometric weights, on the pair as traders quote it. */
export const LEGS = [
  {
    id: "eur",
    name: "Euro",
    pair: "EURUSD",
    weight: -0.576,
    weightLabel: "57,6%",
  },
  {
    id: "jpy",
    name: "Yen",
    pair: "USDJPY",
    weight: 0.136,
    weightLabel: "13,6%",
  },
  {
    id: "gbp",
    name: "Libra",
    pair: "GBPUSD",
    weight: -0.119,
    weightLabel: "11,9%",
  },
  {
    id: "cad",
    name: "Canadá",
    pair: "USDCAD",
    weight: 0.091,
    weightLabel: "9,1%",
  },
  {
    id: "sek",
    name: "Corona",
    pair: "USDSEK",
    weight: 0.042,
    weightLabel: "4,2%",
  },
  {
    id: "chf",
    name: "Franco",
    pair: "USDCHF",
    weight: 0.036,
    weightLabel: "3,6%",
  },
] as const;

export type LegId = (typeof LEGS)[number]["id"];

export const K_INNER = 0.45;
export const K_OUTER = 0.82;

/**
 * Half-width of a horizon band: k * ATR(14) * sqrt(sessions).
 * 0.45 and 0.82 sit near the 50th and 80th percentile of
 * |move| / (ATR * sqrt(h)) on the 2021–2026 daily sample.
 * The 20-session drift is shrunk hard: that rule only barely beats a coin toss.
 */
export function driftShift(mom20Points: number, atr: number, sessions: number): number {
  const raw = 0.15 * mom20Points * (sessions / 20);
  const cap = 0.35 * K_INNER * atr * Math.sqrt(sessions);
  return Math.min(cap, Math.max(-cap, raw));
}

export function bandFor(spot: number, atr: number, mom20Points: number, sessions: number) {
  const shift = driftShift(mom20Points, atr, sessions);
  const center = spot + shift;
  const inner = K_INNER * atr * Math.sqrt(sessions);
  const outer = K_OUTER * atr * Math.sqrt(sessions);
  return {
    shift,
    center,
    innerLow: center - inner,
    innerHigh: center + inner,
    outerLow: center - outer,
    outerHigh: center + outer,
  };
}

export function coneAt(
  spot: number,
  atr: number,
  mom20Points: number,
  step: number,
  horizon: number,
) {
  const shift = driftShift(mom20Points, atr, horizon) * (step / horizon);
  const half = K_OUTER * atr * Math.sqrt(step);
  const mid = spot + shift;
  return { mid, low: mid - half, high: mid + half };
}

export function emptyShocks(): Record<LegId, number> {
  return { eur: 0, jpy: 0, gbp: 0, cad: 0, sek: 0, chf: 0 };
}

export function projectBasket(spot: number, shocksPct: Record<string, number>) {
  let logShift = 0;
  const parts = LEGS.map((leg) => {
    const pct = shocksPct[leg.id] ?? 0;
    const dln = Math.log1p(pct / 100);
    const points = spot * leg.weight * dln;
    logShift += leg.weight * dln;
    return { id: leg.id, points };
  });
  return { projected: spot * Math.exp(logShift), delta: spot * Math.exp(logShift) - spot, parts };
}
