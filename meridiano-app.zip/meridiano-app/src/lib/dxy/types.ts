import type { LegId } from "@/lib/dxy/ice";

export type Tone = "up" | "down" | "flat";
export type Bias = "alcista" | "bajista" | "neutral";
export type HorizonId = 1 | 5 | 20;

export type SeriesPoint = {
  date: string;
  close: number;
  ema21: number | null;
};

export type Driver = {
  id: string;
  label: string;
  value: string;
  hint: string;
  tone: Tone;
};

export type LegView = {
  id: LegId;
  name: string;
  pair: string;
  weightLabel: string;
  weight: number;
  price: number;
  chg5Pct: number;
  points5: number;
};

export type Level = {
  id: string;
  label: string;
  price: number;
  distance: number;
};

export type HorizonView = {
  id: HorizonId;
  label: string;
  sessions: number;
  center: number;
  shift: number;
  innerLow: number;
  innerHigh: number;
  outerLow: number;
  outerHigh: number;
  innerCover: number;
  outerCover: number;
  coverSamples: number;
  hitRate: number;
  hitSamples: number;
};

export type YieldView = {
  last: number;
  date: string;
  chg10bp: number | null;
  pointsPer10bp: number;
  corr: number;
  samples: number;
};

export type SessionBar = {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
};

export type Snapshot = {
  spot: number;
  prev: number;
  change: number;
  changePct: number;
  atr: number;
  mom20Points: number;
  lastDate: string;
  sessionNote: string;
  fetchedLabel: string;
  reading: string;
  bias: Bias;
  intensity: "nula" | "leve" | "clara";
  tilt: number;
  ema21: number;
  ema55: number;
  session: SessionBar;
  series: SeriesPoint[];
  drivers: Driver[];
  legs: LegView[] | null;
  fxDate: string | null;
  iceChange5: number | null;
  basketPoints5: number | null;
  levels: Level[];
  horizons: HorizonView[];
  yield10: YieldView | null;
  notices: string[];
};

export type MarketResult = { ok: true; snapshot: Snapshot } | { ok: false; error: string };
