import { useState } from "react";
import { useRouter, useRouterState } from "@tanstack/react-router";
import { ChevronDown, RefreshCw } from "lucide-react";
import { PriceChart } from "@/components/meridiano/chart";
import { Scenario, YieldCard } from "@/components/meridiano/scenario";
import { ImpactBar, Panel, toneClass } from "@/components/meridiano/ui";
import { formatDay, formatNum, formatSigned } from "@/lib/dxy/format";
import type { HorizonId, MarketResult } from "@/lib/dxy/types";

const SPANS: { id: number; label: string }[] = [
  { id: 63, label: "3 meses" },
  { id: 126, label: "6 meses" },
  { id: 252, label: "1 año" },
  { id: 0, label: "5 años" },
];

function biasTitle(data: Extract<MarketResult, { ok: true }>["snapshot"]): string {
  if (data.bias === "neutral") return "Sin inclinación";
  return data.bias === "alcista" ? "Inercia al alza" : "Inercia a la baja";
}

function RefreshButton() {
  const router = useRouter();
  const loading = useRouterState({ select: (state) => state.isLoading });
  return (
    <button
      type="button"
      className="pill"
      onClick={() => void router.invalidate()}
      disabled={loading}
    >
      <RefreshCw className="size-4" aria-hidden="true" />
      {loading ? "Actualizando" : "Actualizar"}
    </button>
  );
}

export function Desk({ result }: { result: MarketResult }) {
  const router = useRouter();
  if (!result.ok) {
    return (
      <main className="mx-auto flex min-h-screen w-full max-w-3xl flex-col justify-center px-4 py-16">
        <p className="font-display text-4xl text-balance">Meridiano no pudo leer el índice.</p>
        <p className="mt-3 max-w-lg text-pretty text-muted">{result.error}</p>
        <button type="button" className="pill pill-on mt-6 self-start" onClick={() => void router.invalidate()}>
          Reintentar
        </button>
      </main>
    );
  }

  return <Ready snapshot={result.snapshot} />;
}

function Ready({ snapshot }: { snapshot: Extract<MarketResult, { ok: true }>["snapshot"] }) {
  const [horizon, setHorizon] = useState<HorizonId>(5);
  const [span, setSpan] = useState(126);
  const view = snapshot.horizons.find((item) => item.id === horizon) ?? snapshot.horizons[1];
  const legScale = Math.max(0.15, ...(snapshot.legs?.map((leg) => Math.abs(leg.points5)) ?? [0.15]));
  const meter = ((Math.max(-1, Math.min(1, snapshot.tilt)) + 1) / 2) * 100;

  return (
    <main className="mx-auto w-full max-w-6xl px-4 pt-5 pb-16 sm:px-6">
      <header className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="mark" aria-hidden="true">
            <svg viewBox="0 0 32 32" className="size-6">
              <circle cx="16" cy="16" r="9" fill="none" stroke="currentColor" strokeWidth="1.5" />
              <path d="M16 5.5v21" stroke="var(--color-gold)" strokeWidth="1.75" />
            </svg>
          </span>
          <div>
            <h1 className="font-display text-2xl leading-none">Meridiano</h1>
            <p className="text-sm text-muted">Anticipación del índice dólar</p>
          </div>
        </div>
        <RefreshButton />
      </header>

      <section className="mt-8 grid items-end gap-6 lg:grid-cols-[minmax(0,1.2fr)_minmax(18rem,0.8fr)]">
        <div>
          <p className="text-sm text-muted">Índice dólar ICE · DX-Y.NYB</p>
          <p className="mt-2 font-display text-6xl leading-none tabular-nums sm:text-7xl">
            {formatNum(snapshot.spot)}
          </p>
          <p
            className={
              snapshot.change < 0
                ? "mt-3 text-lg tabular-nums text-down"
                : snapshot.change > 0
                  ? "mt-3 text-lg tabular-nums text-gold"
                  : "mt-3 text-lg tabular-nums text-muted"
            }
          >
            {formatSigned(snapshot.change)}{" "}
            <span className="text-base">({formatSigned(snapshot.changePct)}%)</span>
          </p>
          <p className="mt-1 text-sm text-muted">frente al cierre anterior · {snapshot.sessionNote}</p>
        </div>
        <div className="panel p-4 sm:p-5">
          <p className="text-sm text-muted">Lectura de la inercia</p>
          <p className="mt-1 font-display text-2xl leading-tight text-balance">{biasTitle(snapshot)}</p>
          <div className="relative mt-4 h-8" aria-hidden="true">
            <div className="absolute inset-x-0 top-3 h-1.5 rounded-full bg-inset" />
            <span className="absolute top-2 left-1/2 h-4 w-px bg-line" />
            <span
              className="absolute top-1.5 size-4 rounded-full border-2 border-bg bg-gold"
              style={{ left: `calc(${meter}% - 0.5rem)` }}
            />
          </div>
          <div className="flex justify-between text-sm text-muted">
            <span>Baja</span>
            <span>Sube</span>
          </div>
          <p className="mt-3 text-sm text-pretty text-muted">{snapshot.reading}</p>
        </div>
      </section>

      {snapshot.notices.length > 0 ? (
        <div className="mt-4 space-y-2">
          {snapshot.notices.map((notice) => (
            <p key={notice} className="rounded-xl bg-inset px-4 py-3 text-sm text-pretty text-muted">
              {notice}
            </p>
          ))}
        </div>
      ) : null}

      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div role="group" aria-label="Horizonte" className="flex flex-wrap gap-2">
          {snapshot.horizons.map((item) => (
            <button
              key={item.id}
              type="button"
              aria-pressed={item.id === horizon}
              className={item.id === horizon ? "pill pill-on" : "pill"}
              onClick={() => setHorizon(item.id)}
            >
              {item.label}
            </button>
          ))}
        </div>
        <div role="group" aria-label="Historia del gráfico" className="flex flex-wrap gap-2">
          {SPANS.map((item) => (
            <button
              key={item.id}
              type="button"
              aria-pressed={item.id === span}
              className={item.id === span ? "pill pill-on" : "pill"}
              onClick={() => setSpan(item.id)}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-5">
        <section className="panel p-4 sm:p-5 lg:col-span-3">
          <div className="flex items-baseline justify-between gap-3">
            <h2 className="font-display text-xl">Cierre y rango amplio</h2>
            <p className="text-sm text-muted">a {view.label}</p>
          </div>
          <p className="mt-1 text-sm text-muted">
            Línea clara: el índice. Línea tenue: media de 21. Punteado: banda amplia, no una trayectoria.
          </p>
          <div className="mt-3">
            <PriceChart
              series={snapshot.series}
              span={span}
              horizon={horizon}
              spot={snapshot.spot}
              atr={snapshot.atr}
              mom20Points={snapshot.mom20Points}
              lastDate={snapshot.lastDate}
            />
          </div>
        </section>

        <section className="panel p-4 sm:p-5 lg:col-span-2">
          <h2 className="font-display text-xl">Rango a {view.label}</h2>
          <RangeMeter
            outerLow={view.outerLow}
            outerHigh={view.outerHigh}
            innerLow={view.innerLow}
            innerHigh={view.innerHigh}
            center={view.center}
            spot={snapshot.spot}
          />
          <dl className="mt-4 space-y-3">
            <RangeRow label="Centro" value={formatNum(view.center)} hint={`${formatSigned(view.shift)} pts desde el cierre`} />
            <RangeRow
              label="Banda central"
              value={`${formatNum(view.innerLow)} – ${formatNum(view.innerHigh)}`}
              hint={`contuvo el ${Math.round(view.innerCover * 100)}% de los cierres`}
            />
            <RangeRow
              label="Banda amplia"
              value={`${formatNum(view.outerLow)} – ${formatNum(view.outerHigh)}`}
              hint={`contuvo el ${Math.round(view.outerCover * 100)}% de los cierres`}
            />
          </dl>
          <p className="mt-4 text-sm text-pretty text-muted">
            Medido en {formatNum(view.coverSamples, 0)} ventanas de esta serie. La inercia de 20 sesiones
            acertó el signo a este plazo el {Math.round(view.hitRate * 100)}% de las veces. Oscilación media
            diaria: {formatNum(snapshot.atr)} pts.
          </p>
          <dl className="mt-4 grid grid-cols-4 gap-2 border-t border-line pt-3 text-sm">
            <Mini label="Apertura" value={formatNum(snapshot.session.open)} />
            <Mini label="Máximo" value={formatNum(snapshot.session.high)} />
            <Mini label="Mínimo" value={formatNum(snapshot.session.low)} />
            <Mini label="Cierre" value={formatNum(snapshot.session.close)} />
          </dl>
        </section>
      </div>

      <section className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        {snapshot.drivers.map((driver) => (
          <article key={driver.id} className="panel px-4 py-3">
            <p className="text-sm text-muted">{driver.label}</p>
            <p className={`mt-1 font-display text-2xl leading-tight tabular-nums ${toneClass(driver.tone)}`}>
              {driver.value}
            </p>
            <p className="mt-1 text-sm text-pretty text-muted">{driver.hint}</p>
          </article>
        ))}
      </section>

      <div className="mt-4 grid gap-4 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <Panel
            title="Cesta del índice"
            aside={snapshot.fxDate ? `BCE ${formatDay(snapshot.fxDate)}` : undefined}
          >
            {snapshot.legs && snapshot.iceChange5 != null && snapshot.basketPoints5 != null ? (
              <>
                <p className="text-sm text-pretty text-muted">
                  En 5 sesiones el ICE se movió {formatSigned(snapshot.iceChange5)} pts. La fórmula, con el
                  fixing BCE, atribuye {formatSigned(snapshot.basketPoints5)} pts. La diferencia es normal:
                  Nueva York cierra después que Fráncfort.
                </p>
                <ul className="mt-4 space-y-3">
                  {snapshot.legs.map((leg) => (
                    <li key={leg.id}>
                      <div className="flex items-baseline justify-between gap-3">
                        <p className="text-fg">
                          {leg.name}{" "}
                          <span className="text-sm text-muted">
                            {leg.pair} · {formatNum(leg.price, leg.id === "jpy" || leg.id === "sek" ? 2 : 4)} · peso {leg.weightLabel}
                          </span>
                        </p>
                        <p className={`shrink-0 tabular-nums ${toneClass(leg.points5 > 0 ? "up" : leg.points5 < 0 ? "down" : "flat")}`}>
                          {formatSigned(leg.points5)} pts
                        </p>
                      </div>
                      <div className="mt-2">
                        <ImpactBar value={leg.points5} scale={legScale} />
                      </div>
                      <p className="mt-1 text-sm text-muted tabular-nums">
                        el cruce, {formatSigned(leg.chg5Pct)}% en 5 sesiones
                      </p>
                    </li>
                  ))}
                </ul>
              </>
            ) : (
              <p className="text-sm text-muted">La cesta no está disponible en este momento.</p>
            )}
          </Panel>
        </div>
        <div className="lg:col-span-2">
          <Panel title="Niveles que importan">
            <ul className="divide-y divide-line">
              {snapshot.levels.map((level) => (
                <li key={level.id} className="flex items-baseline justify-between gap-3 py-2.5">
                  <span className="text-sm text-muted">{level.label}</span>
                  <span className="text-right tabular-nums">
                    <span className="block text-fg">{formatNum(level.price)}</span>
                    <span className="block text-sm text-muted">{formatSigned(level.distance)} pts</span>
                  </span>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-sm text-pretty text-muted">
              La cifra pequeña es la distancia del nivel al cierre. Si es positiva, el nivel está por encima.
            </p>
          </Panel>
        </div>
      </div>

      <div className={snapshot.yield10 ? "mt-4 grid gap-4 lg:grid-cols-3" : "mt-4"}>
        <div className={snapshot.yield10 ? "lg:col-span-2" : undefined}>
          <Scenario spot={snapshot.spot} available={snapshot.legs != null} />
        </div>
        {snapshot.yield10 ? <YieldCard spot={snapshot.spot} yield10={snapshot.yield10} /> : null}
      </div>

      <details className="panel group mt-4">
        <summary className="flex min-h-12 cursor-pointer list-none items-center justify-between gap-3 p-4 sm:p-5">
          <span className="font-display text-xl">Cómo está calculado</span>
          <ChevronDown className="size-5 shrink-0 text-muted transition-transform group-open:rotate-180" aria-hidden="true" />
        </summary>
        <div className="space-y-3 px-4 pb-5 text-sm text-pretty text-muted sm:px-5">
          <p>
            Meridiano no adivina el próximo tick. El ancho de la banda sale del ATR de 14 sesiones,
            escalado con la raíz del plazo. En esta misma historia, la banda estrecha contuvo cerca de la
            mitad de los cierres y la amplia cerca de ocho de cada diez. Por eso el rango es la anticipación
            seria, y la flecha direccional va recortada.
          </p>
          <p>
            La inclinación es solo la variación de 20 sesiones, multiplicada por 0,15 y limitada para que no
            se coma la banda. El acierto que ves es el de ese criterio, medido hacia delante dentro de la
            serie: no es una prueba fuera de muestra y no mejora mucho a una moneda.
          </p>
          <p>
            La cesta usa los pesos oficiales del ICE: euro 57,6%, yen 13,6%, libra 11,9%, dólar canadiense
            9,1%, corona sueca 4,2% y franco suizo 3,6%. Los cruces salen del fixing BCE. El índice y el
            bono a 10 años son el cierre de ICE y del Treasury Note en Yahoo Finance.
          </p>
          <p>Actualizado {snapshot.fetchedLabel}, hora de Madrid. No es asesoramiento de inversión.</p>
        </div>
      </details>
    </main>
  );
}

function RangeRow({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <dt className="text-sm text-muted">{label}</dt>
      <dd className="text-right">
        <span className="block tabular-nums text-fg">{value}</span>
        <span className="block text-sm text-muted">{hint}</span>
      </dd>
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-muted">{label}</dt>
      <dd className="tabular-nums text-fg">{value}</dd>
    </div>
  );
}

function RangeMeter({
  outerLow,
  outerHigh,
  innerLow,
  innerHigh,
  center,
  spot,
}: {
  outerLow: number;
  outerHigh: number;
  innerLow: number;
  innerHigh: number;
  center: number;
  spot: number;
}) {
  const span = outerHigh - outerLow || 1;
  const pos = (price: number) => {
    const raw = ((price - outerLow) / span) * 100;
    return Math.min(98, Math.max(2, raw));
  };
  const innerLeft = pos(innerLow);
  const innerWidth = Math.max(0, pos(innerHigh) - innerLeft);
  return (
    <div
      className="relative mt-4 h-10"
      role="img"
      aria-label={`Rango amplio de ${formatNum(outerLow)} a ${formatNum(outerHigh)}. Cierre en ${formatNum(spot)}. Centro en ${formatNum(center)}.`}
    >
      <div className="absolute inset-x-0 top-4 h-2 rounded-full bg-inset" />
      <div
        className="absolute top-4 h-2 rounded-full bg-band"
        style={{ left: `${innerLeft}%`, width: `${innerWidth}%` }}
      />
      <span className="absolute top-3 h-4 w-px bg-fg" style={{ left: `${pos(center)}%` }} />
      <span
        className="absolute top-2 size-4 rounded-full border-2 border-bg bg-gold"
        style={{ left: `calc(${pos(spot)}% - 0.5rem)` }}
      />
    </div>
  );
}
