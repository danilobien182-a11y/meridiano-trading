import { useMemo } from "react";
import {
  CartesianGrid,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  ComposedChart,
} from "recharts";
import { addBusinessDays, formatDay, formatDayShort, formatNum } from "@/lib/dxy/format";
import { coneAt } from "@/lib/dxy/ice";
import type { HorizonId, SeriesPoint } from "@/lib/dxy/types";

type Row = {
  date: string;
  close: number | null;
  ema21: number | null;
  mid: number | null;
  low: number | null;
  high: number | null;
};

function Tip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ payload: Row }>;
}) {
  if (!active || !payload?.length) return null;
  const row = payload[0].payload;
  return (
    <div className="rounded-lg bg-raised px-3 py-2 text-sm shadow-card">
      <p className="text-muted">{formatDay(row.date)}</p>
      {row.close != null ? (
        <p className="tabular-nums text-fg">Cierre {formatNum(row.close)}</p>
      ) : null}
      {row.ema21 != null ? (
        <p className="tabular-nums text-muted">Media 21 {formatNum(row.ema21)}</p>
      ) : null}
      {row.mid != null && row.close == null ? (
        <p className="tabular-nums text-fg">
          Rango {formatNum(row.low ?? row.mid)} – {formatNum(row.high ?? row.mid)}
        </p>
      ) : null}
    </div>
  );
}

export function PriceChart({
  series,
  span,
  horizon,
  spot,
  atr,
  mom20Points,
  lastDate,
}: {
  series: SeriesPoint[];
  span: number;
  horizon: HorizonId;
  spot: number;
  atr: number;
  mom20Points: number;
  lastDate: string;
}) {
  const data = useMemo(() => {
    const sliced = span > 0 ? series.slice(-span) : series;
    const rows: Row[] = sliced.map((point) => ({
      date: point.date,
      close: point.close,
      ema21: point.ema21,
      mid: null,
      low: null,
      high: null,
    }));
    for (let step = 1; step <= horizon; step++) {
      const date = addBusinessDays(lastDate, step);
      const cone = coneAt(spot, atr, mom20Points, step, horizon);
      rows.push({
        date,
        close: null,
        ema21: null,
        mid: cone.mid,
        low: cone.low,
        high: cone.high,
      });
    }
    if (rows.length) {
      const join = rows[rows.length - 1 - horizon];
      if (join) {
        join.mid = spot;
        join.low = spot;
        join.high = spot;
      }
    }
    return rows;
  }, [series, span, horizon, spot, atr, mom20Points, lastDate]);

  const ticks = useMemo(() => {
    if (data.length < 2) return data.map((row) => row.date);
    const out: string[] = [];
    for (let i = 0; i <= 4; i++) {
      const idx = Math.round((i * (data.length - 1)) / 4);
      out.push(data[idx].date);
    }
    return [...new Set(out)];
  }, [data]);

  return (
    <div className="h-72 w-full min-w-0 sm:h-80">
      <ResponsiveContainer width="100%" height="100%" initialDimension={{ width: 720, height: 320 }}>
        <ComposedChart data={data} margin={{ top: 8, right: 0, left: 0, bottom: 0 }}>
          <CartesianGrid vertical={false} stroke="var(--color-line)" />
          <XAxis
            dataKey="date"
            ticks={ticks}
            tickFormatter={formatDayShort}
            tick={{ fill: "var(--color-muted)", fontSize: 12 }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            orientation="right"
            domain={["auto", "auto"]}
            tickFormatter={(v: number) => formatNum(v, 1)}
            width={52}
            tick={{ fill: "var(--color-muted)", fontSize: 12 }}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip
            content={<Tip />}
            cursor={{ stroke: "var(--color-line)" }}
            wrapperStyle={{ background: "transparent", border: "none", boxShadow: "none", padding: 0 }}
          />
          <Line
            type="monotone"
            dataKey="ema21"
            stroke="var(--color-faint)"
            strokeWidth={1.25}
            dot={false}
            connectNulls={false}
            isAnimationActive={false}
          />
          <Line
            type="monotone"
            dataKey="high"
            stroke="var(--color-gold)"
            strokeOpacity={0.45}
            strokeDasharray="3 4"
            strokeWidth={1.25}
            dot={false}
            connectNulls
            isAnimationActive={false}
          />
          <Line
            type="monotone"
            dataKey="low"
            stroke="var(--color-gold)"
            strokeOpacity={0.45}
            strokeDasharray="3 4"
            strokeWidth={1.25}
            dot={false}
            connectNulls
            isAnimationActive={false}
          />
          <Line
            type="monotone"
            dataKey="mid"
            stroke="var(--color-gold)"
            strokeWidth={1.5}
            dot={false}
            connectNulls
            isAnimationActive={false}
          />
          <Line
            type="monotone"
            dataKey="close"
            stroke="var(--color-fg)"
            strokeWidth={1.75}
            dot={false}
            connectNulls={false}
            isAnimationActive={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
