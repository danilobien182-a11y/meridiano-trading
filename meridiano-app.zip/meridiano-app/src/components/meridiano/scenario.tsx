import { useMemo, useState } from "react";
import { formatNum, formatSigned } from "@/lib/dxy/format";
import { emptyShocks, LEGS, projectBasket, type LegId } from "@/lib/dxy/ice";
import type { YieldView } from "@/lib/dxy/types";
import { ImpactBar, Panel } from "@/components/meridiano/ui";

const PRESETS: { id: string; label: string; shocks: Record<LegId, number> }[] = [
  { id: "flat", label: "Sin shock", shocks: emptyShocks() },
  {
    id: "broad",
    label: "Dólar amplio",
    shocks: { eur: -0.5, jpy: 0.5, gbp: -0.5, cad: 0.5, sek: 0.5, chf: 0.5 },
  },
  {
    id: "soft",
    label: "Dólar débil",
    shocks: { eur: 0.5, jpy: -0.5, gbp: 0.5, cad: -0.5, sek: -0.5, chf: -0.5 },
  },
  {
    id: "euro",
    label: "Euro firme",
    shocks: { eur: 0.8, jpy: 0, gbp: 0.2, cad: 0, sek: 0, chf: 0 },
  },
  {
    id: "haven",
    label: "Refugio",
    shocks: { eur: -0.3, jpy: -1, gbp: -0.2, cad: 0.2, sek: 0.3, chf: -0.6 },
  },
];

function sameShocks(a: Record<string, number>, b: Record<string, number>): boolean {
  return LEGS.every((leg) => Math.abs((a[leg.id] ?? 0) - (b[leg.id] ?? 0)) < 0.05);
}

export function Scenario({ spot, available }: { spot: number; available: boolean }) {
  const [shocks, setShocks] = useState(emptyShocks);

  const projection = useMemo(() => projectBasket(spot, shocks), [spot, shocks]);
  const scale = Math.max(0.2, ...projection.parts.map((part) => Math.abs(part.points)));

  if (!available) {
    return (
      <Panel title="Escenarios de la cesta">
        <p className="text-sm text-pretty text-muted">
          Sin el fixing del BCE no se puede mover la cesta. El rango del índice, arriba, no depende de esto.
        </p>
      </Panel>
    );
  }

  return (
    <Panel
      title="Escenarios de la cesta"
      aside="choque sobre cada cruce"
    >
      <div className="flex flex-wrap gap-2">
        {PRESETS.map((preset) => {
          const on = sameShocks(shocks, preset.shocks);
          return (
            <button
              key={preset.id}
              type="button"
              aria-pressed={on}
              className={on ? "pill pill-on" : "pill"}
              onClick={() => setShocks({ ...preset.shocks })}
            >
              {preset.label}
            </button>
          );
        })}
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
        <p className="max-w-xl text-sm text-pretty text-muted">
          Mueve un cruce y el índice responde con la fórmula del ICE, aplicada sobre el cierre de hoy.
          No es una predicción: es la aritmética de la cesta. El euro pesa más de la mitad.
        </p>
        <div className="sm:text-right">
          <p className="text-sm text-muted">Índice resultante</p>
          <p className="font-display text-4xl leading-none tabular-nums">
            {formatNum(projection.projected)}
          </p>
          <p className={projection.delta >= 0 ? "mt-1 tabular-nums text-gold" : "mt-1 tabular-nums text-down"}>
            {formatSigned(projection.delta)} pts
          </p>
        </div>
      </div>

      <ul className="mt-5 divide-y divide-line">
        {LEGS.map((leg) => {
          const value = shocks[leg.id];
          const points = projection.parts.find((part) => part.id === leg.id)?.points ?? 0;
          return (
            <li key={leg.id} className="grid gap-2 py-3 sm:grid-cols-[9rem_minmax(0,1fr)_7rem] sm:items-center">
              <div>
                <label htmlFor={`shock-${leg.id}`} className="block text-fg">
                  {leg.name}
                </label>
                <p className="text-sm text-muted">
                  {leg.pair} · {leg.weightLabel}
                </p>
              </div>
              <div>
                <input
                  id={`shock-${leg.id}`}
                  type="range"
                  min={-2}
                  max={2}
                  step={0.1}
                  value={value}
                  aria-valuetext={`${formatSigned(value, 1)} por ciento en ${leg.pair}`}
                  onChange={(event) =>
                    setShocks((current) => ({ ...current, [leg.id]: Number(event.target.value) }))
                  }
                />
                <p className="text-sm text-muted">
                  {leg.weight < 0 ? "Si este cruce sube, el índice baja." : "Si este cruce sube, el índice sube."}
                </p>
              </div>
              <div className="sm:text-right">
                <p className="tabular-nums text-fg">{formatSigned(value, 1)}%</p>
                <p className={points >= 0 ? "tabular-nums text-sm text-gold" : "tabular-nums text-sm text-down"}>
                  {formatSigned(points)} pts
                </p>
              </div>
            </li>
          );
        })}
      </ul>
      <div className="mt-2">
        <ImpactBar value={projection.delta} scale={scale} />
        <p className="mt-2 text-sm text-muted">
          La barra resume el efecto neto. A la derecha el dólar sube; a la izquierda, baja.
        </p>
      </div>
    </Panel>
  );
}

export function YieldCard({ spot, yield10 }: { spot: number; yield10: YieldView }) {
  const [bp, setBp] = useState(0);
  const points = (bp / 10) * yield10.pointsPer10bp;
  const up = yield10.pointsPer10bp >= 0;

  return (
    <Panel title="Si se mueven los tipos" aside={formatNum(yield10.last, 2) + "%"}>
      <p className="text-sm text-pretty text-muted">
        En {formatIntSafe(yield10.samples)} sesiones, 10 pb del bono a 10 años coincidieron el mismo día con{" "}
        <span className={up ? "text-gold" : "text-down"}>
          {formatSigned(yield10.pointsPer10bp)} pts
        </span>{" "}
        del índice. Correlación {formatNum(yield10.corr, 2)}. Es una asociación histórica, y no se suma a la cesta.
      </p>
      <label htmlFor="yield-bp" className="mt-4 block text-fg">
        Choque en el 10 años
      </label>
      <input
        id="yield-bp"
        type="range"
        min={-30}
        max={30}
        step={1}
        value={bp}
        aria-valuetext={`${formatSigned(bp, 0)} puntos básicos`}
        onChange={(event) => setBp(Number(event.target.value))}
      />
      <p className="mt-2 font-display text-3xl leading-none tabular-nums">
        {formatNum(spot + points)}
      </p>
      <p className="mt-1 text-sm text-muted tabular-nums">
        {formatSigned(bp, 0)} pb → {formatSigned(points)} pts sobre el cierre
      </p>
    </Panel>
  );
}

function formatIntSafe(n: number): string {
  return formatNum(n, 0);
}
