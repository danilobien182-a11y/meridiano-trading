import type { ReactNode } from "react";
import type { Tone } from "@/lib/dxy/types";

export function Panel({
  title,
  aside,
  children,
}: {
  title: string;
  aside?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="panel p-4 sm:p-5">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="font-display text-xl leading-tight text-balance">{title}</h2>
        {aside ? <div className="shrink-0 text-sm text-muted">{aside}</div> : null}
      </div>
      <div className="mt-4">{children}</div>
    </section>
  );
}

export function toneClass(tone: Tone): string {
  if (tone === "up") return "text-gold";
  if (tone === "down") return "text-down";
  return "text-fg";
}

export function ImpactBar({ value, scale }: { value: number; scale: number }) {
  const pct = scale <= 0 ? 0 : Math.min(50, (Math.abs(value) / scale) * 50);
  const up = value >= 0;
  return (
    <div className="relative h-2 rounded-full bg-inset" aria-hidden="true">
      <span className="absolute top-0 left-1/2 h-full w-px bg-line" />
      {pct > 0 ? (
        <span
          className={up ? "absolute top-0 h-full rounded-full bg-gold" : "absolute top-0 h-full rounded-full bg-down"}
          style={up ? { left: "50%", width: `${pct}%` } : { left: `${50 - pct}%`, width: `${pct}%` }}
        />
      ) : null}
    </div>
  );
}
