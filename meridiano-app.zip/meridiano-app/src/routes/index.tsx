import { createFileRoute } from "@tanstack/react-router";
import { Desk } from "@/components/meridiano/desk";
import { getMarket } from "@/lib/dxy/market";

export const Route = createFileRoute("/")({
  loader: () => getMarket(),
  staleTime: 5 * 60 * 1000,
  component: Home,
});

function Home() {
  const result = Route.useLoaderData();
  return <Desk result={result} />;
}
