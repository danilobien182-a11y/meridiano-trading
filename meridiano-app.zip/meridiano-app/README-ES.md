# Meridiano — panel de análisis del índice dólar (DXY)

Meridiano es una aplicación web para consultar la cotización histórica del DXY, revisar su inercia en distintos horizontes, visualizar rangos y explorar escenarios de la cesta del índice y su relación histórica con los rendimientos del bono estadounidense a 10 años.

## Cómo usarla

### Opción recomendada: publicar en Vercel
1. Descomprime este proyecto.
2. Sube la carpeta a un repositorio de GitHub.
3. Entra a https://vercel.com/ e importa ese repositorio.
4. Mantén el comando de construcción configurado como `npm run build`.
5. Publica la aplicación. Una vez desplegada, abre el enlace público desde tu celular o computador.

### Ejecutarla en un entorno de desarrollo
Necesitas Node.js 20 o posterior y npm:
```bash
npm install
npm run dev
```
Abre la dirección local que indique el entorno.

## Datos y límites
- La aplicación consulta datos externos de Yahoo Finance y Frankfurter. Necesita conexión a internet y esos proveedores pueden limitar o cambiar sus respuestas.
- Los datos pueden tener retraso y no garantizan precios ejecutables en un bróker.
- Las proyecciones y correlaciones son estadísticas/escenarios, no señales seguras de compra o venta ni asesoría financiera.
- Si el panel no logra cargar el DXY, usa el botón **Actualizar** más tarde.

## Contenido del proyecto
- `src/routes/index.tsx`: pantalla principal.
- `src/components/meridiano/`: panel, gráficos y escenarios.
- `src/lib/dxy/`: consulta, procesamiento y análisis de los datos.
